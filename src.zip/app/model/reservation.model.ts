export class ReservationModel{

    constructor(public key: string,
    			public idTrajet:string,
                public idUser:string){}
}