export class VoitureModel{
    
    constructor(public key: string,
    			public num:string,
                public marque:string,
                public modele:string,
                public couleur:string,
                public idUser:string){}
}