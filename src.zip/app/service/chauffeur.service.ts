import { Injectable } from '@angular/core';

import { AngularFireDatabase } from '@angular/fire/database';

import { ChauffeurModel } from '../model/chauffeur.model';

@Injectable({
  providedIn: 'root'
})
export class ChauffeurService { 

	private chauffeurs:ChauffeurModel[] = [];

	constructor(private fireDB: AngularFireDatabase) {
		this.chauffeurs = this.getToDatabase();
	}

	addChauffeur(chauffeur){
		this.fireDB.list('/Chauffeur').push({
			cni: chauffeur.cni,
			permis: chauffeur.permis,
			categorie: chauffeur.categorie,
			idUser: chauffeur.idUser
		});
	}

	getChauffeur(email:string):ChauffeurModel{
		for (var i = 0; i < this.chauffeurs.length; i++) {
			if (this.chauffeurs[i].idUser.toLowerCase() == email.toLowerCase()) {
				return this.chauffeurs[i];
			}
		};
		return null;
	}

	updateChauffeur(chauffeur:ChauffeurModel){
		this.fireDB.list('/Chauffeur').update(chauffeur.key, {
			cni: chauffeur.cni,
			permis: chauffeur.permis,
			categorie: chauffeur.categorie,
			idUser: chauffeur.idUser
		});
	}

	deleteChauffeur(chauffeur:ChauffeurModel){
		this.fireDB.list('/Chauffeur').remove(chauffeur.key);
	}


	getToDatabase(): ChauffeurModel[]{
		let trajetsToDB: ChauffeurModel[] = [];

		this.fireDB.list('/Chauffeur').snapshotChanges(['child_added']).subscribe(data => {
			data.forEach(action => {
				trajetsToDB.push(
					new ChauffeurModel(action.payload.key,
									action.payload.exportVal().cni,
									action.payload.exportVal().permis,
									action.payload.exportVal().categorie,
									action.payload.exportVal().idUser)
				);
			});
		});
		return trajetsToDB;
	}
  
}
