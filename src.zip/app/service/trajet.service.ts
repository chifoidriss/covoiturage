import { Injectable } from '@angular/core';

import { AngularFireDatabase } from '@angular/fire/database';

import { TrajetModel } from '../model/trajet.model';

@Injectable({
  providedIn: 'root'
})
export class TrajetService {

	private trajets:TrajetModel[] = [];

	constructor(private fireDB: AngularFireDatabase) {
		this.getToDatabase();
	}

	addTrajet(trajet){
		this.fireDB.list('/Trajet').push({
			depart: trajet.depart,
			arrivee: trajet.arrivee,
			dateDepart: trajet.dateDepart,
			prix: trajet.prix,
			nbPlaces: trajet.nbPlaces,
			idUser: trajet.idUser
		});
	}

	getTrajets():TrajetModel[] {
		return this.trajets;
	}

	getTrajet(key:string):TrajetModel{
		let index:number = this.trajets.findIndex(trajetEl =>{
			if (trajetEl.key == key) {
				return true;
			}
		});
		if (index != -1) {
			return this.trajets[index];
		}else{
			return null;
		}
	}

	getAllTrajet(email:string):TrajetModel[]{ // Pour récupérer les trajets d'un chauffeur 
		let allTrajects:TrajetModel[] = [];
		for (var i = 0; i < this.trajets.length; i++) {
			if (this.trajets[i].idUser.toLowerCase() == email.toLowerCase()) {
				allTrajects.push(this.trajets[i]);
			}
		}
		return allTrajects;
	}

	updateTrajet(trajet:TrajetModel){
		this.fireDB.list('/Trajet').update(trajet.key, {
			depart: trajet.depart,
			arrivee: trajet.arrivee,
			dateDepart: trajet.dateDepart,
			prix: trajet.prix,
			nbPlaces: trajet.nbPlaces,
			idUser: trajet.idUser
		});
	}

	deleteTrajet(trajet:TrajetModel){
		this.fireDB.list('/Trajet').remove(trajet.key);
	}

	rechercheTrajet(depart:string,arrivee:string):TrajetModel[]{
		let allTrajects:TrajetModel[] = [];
		if(depart.length>0 && arrivee.length>0){
			for (var i = 0; i < this.trajets.length; i++) {
				if (this.trajets[i].depart.toLowerCase() == depart.toLowerCase() && this.trajets[i].arrivee.toLowerCase() == arrivee.toLowerCase()) {
					allTrajects.push(this.trajets[i]);
				}
			};
		}else if(depart.length>0 && arrivee.length==0){
			for (var i = 0; i < this.trajets.length; i++) {
				if (this.trajets[i].depart.toLowerCase() == depart.toLowerCase()) {
					allTrajects.push(this.trajets[i]);
				}
			}
		}else if(depart.length==0 && arrivee.length>0){
			for (var i = 0; i < this.trajets.length; i++) {
				if (this.trajets[i].arrivee.toLowerCase() == arrivee.toLowerCase()) {
					allTrajects.push(this.trajets[i]);
				}
			}
		}
		return allTrajects;	
	}

	getToDatabase():TrajetModel[]{
		// let trajetsToDB: TrajetModel[] = [];

		this.fireDB.list('/Trajet').snapshotChanges(['child_changed','child_added','child_removed','child_moved']).subscribe(data => {
			this.trajets = [];
			data.forEach(action => {
				this.trajets.push(
					new TrajetModel(action.payload.key,
								  action.payload.exportVal().depart,
								  action.payload.exportVal().arrivee,
								  action.payload.exportVal().dateDepart,
								  action.payload.exportVal().prix,
								  action.payload.exportVal().nbPlaces,
								  action.payload.exportVal().idUser)
				);
			});
		});
		return this.trajets;
	}
}
