import { Injectable } from '@angular/core';

import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFireDatabase } from '@angular/fire/database';

import { UserModel } from '../model/user.model';

@Injectable({
  providedIn: 'root'
})

export class UserService {
	
	private users:UserModel[] = [];

	constructor(private fireDB: AngularFireDatabase,
				private fireAuth: AngularFireAuth) {
		this.users = this.getToDatabase();
	}

	getUser(email:string):UserModel{
		let listUsers = this.getToDatabase();
		for (var i = 0; i < listUsers.length; i++) {
			if (listUsers[i].email.toLowerCase() == email.toLowerCase()) {
				return listUsers[i];
			}
		}
		return null;
	}

	connectUser(email:string,password:string){
		return new Promise((resolve,reject) => {
			this.fireAuth.auth.signInWithEmailAndPassword(email,password).then(
				() => { 
					resolve(); 
				},
				(error) => { 
					reject(error); 
				}
			);
		});
	}

	addUser(user){
		this.fireDB.list('/User').push({
			nom: user.nom,
			prenom: user.prenom,
			email: user.email,
			phone: user.phone
		});
	}

	createNewUser(email:string,password:string){
		return new Promise((resolve,reject) => {
			this.fireAuth.auth.createUserWithEmailAndPassword(email,password).then(
				() => {
					resolve();
				},
				(error) => {
					reject(error);
				}
			);
		});
	}

	updateUser(user){
		this.fireDB.list('/User').update(user.key, {
			nom: user.nom,
			prenom: user.prenom,
			email: user.email,
			phone: user.phone
		});
	}

	deleteUser(user:UserModel){
		this.fireDB.list('/User').remove(user.key);
	}

	logout(){
		this.fireAuth.auth.signOut();
	}

	getToDatabase(): UserModel[]{
		let usersToDB: UserModel[] = [];

		this.fireDB.list('/User').snapshotChanges(['child_added']).subscribe(data => {
			usersToDB = [];
			data.forEach(action => {
				usersToDB.push(
					new UserModel(action.payload.key,
								  action.payload.exportVal().nom,
								  action.payload.exportVal().prenom,
								  action.payload.exportVal().email,
								  action.payload.exportVal().phone)
				);
			});
		});
		return usersToDB;
	}
}
