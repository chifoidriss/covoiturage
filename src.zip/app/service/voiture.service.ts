import { Injectable } from '@angular/core';

import { AngularFireDatabase } from '@angular/fire/database';

import { VoitureModel } from '../model/voiture.model';

@Injectable({
  providedIn: 'root'
})
export class VoitureService {

	private voitures:VoitureModel[] = [];

	constructor(private fireDB: AngularFireDatabase) {
		this.voitures = this.getToDatabase();
	}

	addVoiture(voiture){
		this.fireDB.list('/Voiture').push({
			num: voiture.num,
			marque: voiture.marque,
			modele: voiture.modele,
			couleur: voiture.couleur,
			idUser: voiture.idUser
		});
	}

	getVoiture(email):VoitureModel{
		let index:number = this.voitures.findIndex(voitureEl =>{
			if (voitureEl.idUser == email) {
				return true;
			}
		});
		if (index != -1) {
			return this.voitures[index];
		}else{
			return null;
		}
	}

	updateVoiture(voiture:VoitureModel){
		this.fireDB.list('/Voiture').update(voiture.key, {
			num: voiture.num,
			marque: voiture.marque,
			modele: voiture.modele,
			couleur: voiture.couleur,
			idUser: voiture.idUser
		});
	}

	deleteVoiture(voiture:VoitureModel){
		this.fireDB.list('/Voiture').remove(voiture.key);
	}

	getToDatabase(): VoitureModel[]{
		let voituresToDB: VoitureModel[] = [];

		this.fireDB.list('/Voiture').snapshotChanges(['child_added']).subscribe(data => {
			data.forEach(action => {
				voituresToDB.push(
					new VoitureModel(action.payload.key,
									action.payload.exportVal().num,
									action.payload.exportVal().marque,
									action.payload.exportVal().modele,
									action.payload.exportVal().couleur,
									action.payload.exportVal().idUser)
				);
			});
		});
		return voituresToDB;
	}

}
