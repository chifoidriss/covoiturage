import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';

import { TrajetService } from '../service/trajet.service';

import { AngularFireAuth } from '@angular/fire/auth';

@Component({
  selector: 'app-ajout-trajet',
  templateUrl: './ajout-trajet.page.html',
  styleUrls: ['./ajout-trajet.page.scss'],
})
export class AjoutTrajetPage {

  trajet:any = {
    depart: '',
    arrivee: '',
    dateDepart: new Date().toISOString(),
    prix: null,
    nbPlaces: null
  };

  email:string;

  constructor(private fireAuth: AngularFireAuth,
              private navCtrl: NavController,
              private trajetService: TrajetService) {

    this.fireAuth.authState.subscribe(auth => {
      if (auth) {
        this.email = auth.email;
      }
    });
  }

  ajoutTrajet(){
    let newTrajet = {
      depart: this.trajet.depart,
      arrivee: this.trajet.arrivee,
      dateDepart: this.trajet.dateDepart,
      prix: this.trajet.prix,
      nbPlaces: this.trajet.nbPlaces,
      idUser: this.email
    };
    this.trajetService.addTrajet(newTrajet);
    this.navCtrl.pop();
  }

}
