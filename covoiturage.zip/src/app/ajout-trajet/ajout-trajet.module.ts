import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AjoutTrajetPageRoutingModule } from './ajout-trajet-routing.module';

import { AjoutTrajetPage } from './ajout-trajet.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AjoutTrajetPageRoutingModule
  ],
  declarations: [AjoutTrajetPage]
})
export class AjoutTrajetPageModule {}
