export class ChauffeurModel{
    
    constructor(public key:string,
    			public cni:string,
                public permis:string,
                public categorie:string,
                public idUser:string){}
}