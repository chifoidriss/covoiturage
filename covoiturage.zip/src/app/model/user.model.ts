export class UserModel {

	constructor(public key: string,
				public nom: string,
				public prenom: string,
				public email: string,
				public phone: number) {
	}
}
