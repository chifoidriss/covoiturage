import { Component, ElementRef, AfterViewInit, ViewChild } from '@angular/core';
import { ModalController, ToastController, NavParams } from '@ionic/angular';

import { AngularFireAuth } from '@angular/fire/auth';

import { TrajetModel } from '../model/trajet.model';

import { UserService } from '../service/user.service';
import { UserModel } from '../model/user.model';

import { ReservationService } from '../service/reservation.service';
import { ReservationModel } from '../model/reservation.model';

import { VoitureService } from '../service/voiture.service';
import { VoitureModel } from '../model/voiture.model';

import { ChauffeurModel } from '../model/chauffeur.model';
import { ChauffeurService } from '../service/chauffeur.service';


declare var google;

@Component({
  selector: 'app-reservation',
  templateUrl: './reservation.page.html',
  styleUrls: ['./reservation.page.scss'],
})
export class ReservationPage implements AfterViewInit {

	trajet:TrajetModel;
	email:string;
	nbR:number;

	@ViewChild('mapElement', { static: false }) mapNativeElement: ElementRef;
	directionsService = new google.maps.DirectionsService;
	directionsDisplay = new google.maps.DirectionsRenderer;
	
	constructor(private fireAuth: AngularFireAuth,
				private modalCtrl: ModalController,
				private toastCtrl: ToastController,
				private navParams: NavParams,
				private userService: UserService,
				private reserveService: ReservationService,
				private voitureService: VoitureService,
				private chauffeurService: ChauffeurService) {
		
		this.trajet = navParams.get('trajet');

		this.fireAuth.authState.subscribe(auth => {
			if (auth) {
				this.email = auth.email;
			}
		});

		this.nbR = this.reserveService.getTrajetReservation(this.trajet.key).length;
		this.calculateAndDisplayRoute();
	}

	user(email:string):UserModel{
		return this.userService.getUser(email);
	}

	voiture(email:string):VoitureModel{
		return this.voitureService.getVoiture(email);
	}

	chauffeur(email:string):ChauffeurModel{
		return this.chauffeurService.getChauffeur(email);
	}

	close() {
		this.modalCtrl.dismiss();
	}

	async reserver() {
		let R = {idTrajet:this.trajet.key, idUser:this.email};
		this.reserveService.addReservation(R);
		
		const toast = await this.toastCtrl.create({
              message: 'Réservation éffectuée avec succès!',
              showCloseButton:true,
              closeButtonText:'OK',
              position: 'top',
              duration: 5000
            });
		this.modalCtrl.dismiss();
        return await toast.present();
	}


	ngAfterViewInit():void {   
	    const map = new google.maps.Map(this.mapNativeElement.nativeElement, {
	      	zoom: 7,
	      	center: { lat:  4.061536, lng: 9.786072 }
	    });
	    this.directionsDisplay.setMap(map);
  	}

	calculateAndDisplayRoute() {
		const that = this;
		console.log(this.trajet)
		this.directionsService.route({
			origin: this.trajet.depart,
			destination: this.trajet.arrivee,
			travelMode: 'DRIVING'
		}, (response, status) => {
			if (status === 'OK') {
				that.directionsDisplay.setDirections(response);
			} else {
				window.alert('Directions request failed due to ' + status);
			}
		});
	}

}
